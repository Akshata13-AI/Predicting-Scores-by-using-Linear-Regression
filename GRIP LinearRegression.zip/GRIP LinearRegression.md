### Author - Akshata Anil Shukla

## Predicting no of hours by using Linear Regression

### In the regression task we will predit the percentage of marks that a student is expected to score based upon the number of hours they studied. This is a simple linear regression task as it involves two variables.


```python
# import the libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set(color_codes=True)
%matplotlib inline
```


```python
# Import the dataset[ here i am downloaded the dataset from "http://bit.ly/w-data" in the form of text]
student = pd.read_csv('student.txt')
print("Importing dataset, done!!")
student.head()
```

    Importing dataset, done!!
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Hours</th>
      <th>Scores</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2.5</td>
      <td>21</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5.1</td>
      <td>47</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.2</td>
      <td>27</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8.5</td>
      <td>75</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3.5</td>
      <td>30</td>
    </tr>
  </tbody>
</table>
</div>




```python
# check if there any missing value or null value present
sns.heatmap(student.isnull(),yticklabels=True,cmap='viridis')
```




    <AxesSubplot:>




![png](output_3_1.png)


### From the above graph, we can clearly see that there is no missing value present.


```python
# Plotting the graph to see the correlation between the columns
student.plot(kind='scatter', x='Hours', y='Scores', color ='blue')
plt.title("Scores Vs Hours")
plt.legend()
```

    No handles with labels found to put in legend.
    




    <matplotlib.legend.Legend at 0x1469c7eff48>




![png](output_5_2.png)


### From the above graph, there is positive correlation between columns and we can implement linear regression in them

## Preparing the data


```python
X = student.drop('Scores',axis=1)
y = student['Scores']
```


```python
from sklearn.model_selection import train_test_split
```


```python
 X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
```

### Training the Algorithm


```python
from sklearn.linear_model import LinearRegression
```


```python
logmodel = LinearRegression()
logmodel = logmodel.fit(X_train,y_train)
```


```python
# Plotting the regression line
sns.lmplot(x='Hours',y='Scores',data=student)
```




    <seaborn.axisgrid.FacetGrid at 0x1469c9afd88>




![png](output_14_1.png)


## Making Prediction


```python
y_predict = logmodel.predict(X_test)
```


```python
# Comparing Actual and Predicted values
act_pre_VAL = pd.DataFrame({'Actual': y_test,'Predicted':y_predict})
act_pre_VAL.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Actual</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>20</td>
      <td>16.884145</td>
    </tr>
    <tr>
      <th>2</th>
      <td>27</td>
      <td>33.732261</td>
    </tr>
    <tr>
      <th>19</th>
      <td>69</td>
      <td>75.357018</td>
    </tr>
    <tr>
      <th>16</th>
      <td>30</td>
      <td>26.794801</td>
    </tr>
    <tr>
      <th>11</th>
      <td>62</td>
      <td>60.491033</td>
    </tr>
  </tbody>
</table>
</div>




```python
# we can test the data
pre = logmodel.predict([[10.23]])
pre
```




    array([103.40417584])



## Evaluating the model


```python
# R2 value shows how good our model is.
from sklearn.metrics import r2_score
from sklearn import metrics
```


```python
r2_score = logmodel.score(X_train,y_train)
```


```python
r2_score
```




    0.9515510725211552



#### As from the above line, our model is 95 % accurate


```python
# mean squared error shows the error
mse = metrics.mean_absolute_error(y_test, y_predict)
```


```python
mse
```




    4.183859899002975




```python

```
